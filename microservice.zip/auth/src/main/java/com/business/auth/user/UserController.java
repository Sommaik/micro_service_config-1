package com.business.auth.user;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserController {

    private UserRepository userRepo;

    public UserController(UserRepository userRepo) {
        this.userRepo = userRepo;
    }

    @GetMapping
    public List<User> findAll(
            @RequestAttribute(name = "USER_ID") String userId) {
        System.out.println(userId);
        return this.userRepo.findAll();
    }

    @PostMapping
    public User createUser(@RequestBody Map<String, String> body) {
        User user = new User(body.get("email"), body.get("name"), body.get("password"), body.get("role"));
        User res = this.userRepo.save(user);
        return res;
    }

    @PutMapping("/{id}")
    public Map<String, Object> updateUser(
            @RequestBody Map<String, String> body,
            @PathVariable Long id) {
        Map<String, Object> res = new HashMap<>();
        if (userRepo.existsById(id)) {
            User other = new User(
                    body.get("email"),
                    body.get("name"),
                    body.get("password"),
                    body.get("role"));
            other.setId(id);
            userRepo.save(other);
            res.put("success", true);
            res.put("data", other);
        } else {
            res.put("success", false);
            res.put("message", "no data found");
        }
        return res;
    }

    @DeleteMapping("/{id}")
    public Map<String, Object> deleteUser(@PathVariable Long id) {
        Map<String, Object> res = new HashMap<>();
        if (userRepo.existsById(id)) {
            userRepo.deleteById(id);
            res.put("success", true);
            res.put("data", id);
        } else {
            res.put("success", false);
            res.put("message", "no data found");
        }
        return res;
    }
}
