package com.business.auth.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Example;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTCreator;
import com.auth0.jwt.algorithms.Algorithm;
import com.business.auth.dto.LoginDto;

@RestController
@RequestMapping("/login")
public class LoginController {

    private UserRepository userRepo;

    @Value("${jwt.secret}")
    private String secret;

    public LoginController(UserRepository userRepo) {
        this.userRepo = userRepo;
    }

    @PostMapping
    public String goLogin(
            @RequestBody LoginDto login) {
        User u = new User();
        u.setEmail(login.getUsername());
        u.setPassword(login.getPassword());
        Example<User> f = Example.of(u);
        List<User> user = userRepo.findAll(f);
        if (!user.isEmpty()) {
            User current = user.get(0);
            JWTCreator.Builder builder = JWT.create();
            builder.withClaim("iss", current.getId());
            Algorithm algorithm = Algorithm.HMAC256(this.secret.getBytes());
            String token = builder.sign(algorithm);
            return token;
        } else {
            return "fail";
        }
    }
}
