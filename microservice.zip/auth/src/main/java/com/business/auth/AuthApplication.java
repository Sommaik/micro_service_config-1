package com.business.auth;

import java.util.Optional;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Example;
import org.springframework.web.client.RestTemplate;

import com.business.auth.user.User;
import com.business.auth.user.UserRepository;

@SpringBootApplication
@EnableEurekaClient
public class AuthApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthApplication.class, args);
	}

	@Bean
	public CommandLineRunner initialUserData(UserRepository repository) {
		return (args) -> {
			User ex = new User();
			ex.setEmail("sommai.k@gmail.com");
			Example<User> example = Example.of(ex);
			Optional<User> curr = repository.findOne(example);
			if (curr.isEmpty()) {
				User user = new User("sommai.k@gmail.com", "sommai.k", "1234", "ADMIN");
				repository.save(user);
			}
		};
	}

	@Bean
	@LoadBalanced
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

}
