package com.business.promotion.controller;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/promotion")
public class PromotionController {

    private static final Logger logger = LoggerFactory.getLogger(PromotionController.class);

    @GetMapping("/{promotionCode}")
    Map<String, String> getPromotionCode(
            @PathVariable String promotionCode) {
        // fetch data from db;
        logger.info("fetch data from db");
        Map<String, String> promotion = new HashMap<>();
        promotion.put("code", "BKFEE50");
        promotion.put("amt", "50");
        logger.info("return data from promotion service");
        return promotion;
    }
}
