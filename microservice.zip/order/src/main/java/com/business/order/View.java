package com.business.order;

public class View {
    public interface Summary {
    }
}
