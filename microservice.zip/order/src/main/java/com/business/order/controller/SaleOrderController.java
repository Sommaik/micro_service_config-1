package com.business.order.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.ws.rs.Path;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.business.order.View;
import com.business.order.item.Item;
import com.business.order.item.Product;
import com.business.order.item.ProductRepository;
import com.business.order.item.SaleOrder;
import com.business.order.item.SaleOrderRepository;
import com.fasterxml.jackson.annotation.JsonView;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@RequestMapping("/sale-order")
public class SaleOrderController {

    private static final Logger logger = LoggerFactory.getLogger(SaleOrderController.class);

    private SaleOrderRepository saleRepo;
    private ProductRepository productRepo;
    private RestTemplate restTemplate;

    public SaleOrderController(SaleOrderRepository saleRepo, ProductRepository productRepo, RestTemplate restTemplate) {
        this.saleRepo = saleRepo;
        this.productRepo = productRepo;
        this.restTemplate = restTemplate;
    }

    @GetMapping("/newOrder")
    public SaleOrder createOrder() {
        SaleOrder saleOrder = new SaleOrder(new Date(), "Prepare", null, 0d, 0d, 0d, null);
        saleRepo.save(saleOrder);
        return saleOrder;
    }

    @PostMapping("/addItem/{orderId}")
    public Map<String, Object> addItem(@PathVariable("orderId") long id, @RequestBody Map<String, Object> body) {
        Map<String, Object> res = new HashMap<>();
        Optional<SaleOrder> sale = saleRepo.findById(id);
        if (sale.isPresent()) {
            SaleOrder saleOrder = sale.get();
            List<Product> product = productRepo.findBySku(body.get("sku").toString());
            Double total = product.get(0).getPrice() * (Integer) body.get("qty");
            saleOrder.setNet(total + saleOrder.getNet());
            saleOrder.setSubnet(total + saleOrder.getSubnet());
            Item item = new Item(saleOrder, product.get(0), (Integer) body.get("qty"));
            saleOrder.getItems().add(item);
            saleRepo.save(saleOrder);
            res.put("success", true);
            res.put("data", saleOrder.getId());
        } else {
            res.put("success", false);
            res.put("data", "no data found");
        }
        return res;
    }

    @JsonView(View.Summary.class)
    @GetMapping("/orderDetail/{orderId}")
    public SaleOrder orderDetail(@PathVariable("orderId") long id) {
        SaleOrder saleOrder = null;
        Optional<SaleOrder> sale = saleRepo.findById(id);
        if (sale.isPresent()) {
            saleOrder = sale.get();
        }
        return saleOrder;
    }

    @HystrixCommand(fallbackMethod = "setPromotionFallback")
    @GetMapping("/setPromotion/{id}/{promotionCode}")
    public Map<String, String> setPromotion(
            @PathVariable Long id,
            @PathVariable String promotionCode) {
        logger.info("call to promotion service");
        Map<String, String> object = restTemplate.getForObject("http://promotion-service/promotion/" + promotionCode,
                Map.class);
        logger.info("response from promotion service");
        return object;
    }

    public Map<String, String> setPromotionFallback(Long id, String promotionCode, Throwable hystricCommand) {

        Map<String, String> resp = new HashMap<>();

        resp.put("success", "false");
        resp.put("message", hystricCommand.getMessage());

        return resp;
    }

}
