package com.business.order.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.business.order.item.Product;
import com.business.order.item.ProductRepository;

@RestController
@RequestMapping("/product")
public class ProductController {

    private ProductRepository repo;

    ProductController(ProductRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    List<Product> findAll() {
        return this.repo.findAll();
    }

}
