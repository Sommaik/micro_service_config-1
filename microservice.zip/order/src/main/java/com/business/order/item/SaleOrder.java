package com.business.order.item;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.business.order.View;
import com.fasterxml.jackson.annotation.JsonView;

@Entity
public class SaleOrder {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @JsonView(View.Summary.class)
    Long id;

    @JsonView(View.Summary.class)
    Date date;

    @JsonView(View.Summary.class)
    String status;

    @JsonView(View.Summary.class)
    String promotion;

    @JsonView(View.Summary.class)
    Double subnet;

    @JsonView(View.Summary.class)
    Double discount;

    @JsonView(View.Summary.class)
    Double net;

    @JsonView(View.Summary.class)
    @OneToMany(mappedBy = "saleOrder", cascade = CascadeType.ALL)
    Set<Item> items;

    public SaleOrder() {
    }

    public SaleOrder(Date date, String status, String promotion, Double subnet, Double discount, Double net,
            Set<Item> items) {
        this.date = date;
        this.status = status;
        this.promotion = promotion;
        this.subnet = subnet;
        this.discount = discount;
        this.net = net;
        this.items = items;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPromotion() {
        return promotion;
    }

    public void setPromotion(String promotion) {
        this.promotion = promotion;
    }

    public Double getSubnet() {
        return subnet;
    }

    public void setSubnet(Double subnet) {
        this.subnet = subnet;
    }

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Double getNet() {
        return net;
    }

    public void setNet(Double net) {
        this.net = net;
    }

    public Set<Item> getItems() {
        return items;
    }

    public void setItems(Set<Item> items) {
        this.items = items;
    }

}
