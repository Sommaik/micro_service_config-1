package com.business.order;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import com.business.order.item.Product;
import com.business.order.item.ProductRepository;

@SpringBootApplication
@EnableEurekaClient
@EnableHystrix
public class OrderApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderApplication.class, args);
	}

	@Bean
	public CommandLineRunner initialData(ProductRepository repository) {
		return (args) -> {
			List<Product> allProduct = repository.findAll();
			if (allProduct.size() <= 0) {
				List<Product> newProduct = new ArrayList<>();
				newProduct.add(new Product("10001", "Java version 1.0", "pct", 100d));
				newProduct.add(new Product("10002", "DevOps 1.0", "pct", 230d));
				newProduct.add(new Product("10003", "Spring boot", "pct", 200d));
				newProduct.add(new Product("10004", "Flutter", "pct", 350d));
				repository.saveAll(newProduct);
			}
		};
	}

	@Bean
	@LoadBalanced
	public RestTemplate createRestTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

}
