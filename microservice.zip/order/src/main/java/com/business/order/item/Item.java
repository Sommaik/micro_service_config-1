package com.business.order.item;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.business.order.View;
import com.fasterxml.jackson.annotation.JsonView;

@Entity
public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long id;

    @ManyToOne
    @JoinColumn(name = "saleOrderId")
    SaleOrder saleOrder;

    @ManyToOne
    @JoinColumn(name = "productId")
    @JsonView(View.Summary.class)
    Product product;

    @JsonView(View.Summary.class)
    Integer qty;

    public Item() {
    }

    public Item(SaleOrder saleOrder, Product product, Integer qty) {
        this.saleOrder = saleOrder;
        this.product = product;
        this.qty = qty;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public SaleOrder getSaleOrder() {
        return saleOrder;
    }

    public void setSaleOrder(SaleOrder saleOrder) {
        this.saleOrder = saleOrder;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Integer getQty() {
        return qty;
    }

    public void setQty(Integer qty) {
        this.qty = qty;
    }

}
